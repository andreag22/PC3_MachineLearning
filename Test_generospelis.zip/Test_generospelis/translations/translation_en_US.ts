<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/1</name>
        <message>
            <source>Test vocacional</source>
            <comment>Text</comment>
            <translation type="obsolete">Test vocacional</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Test de géneros de películas</source>
            <comment>Text</comment>
            <translation type="unfinished">Test de géneros de películas</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/2</name>
        <message>
            <source>A continuación mencionaré 10 enunciados, dependiendo de que tan identificado te sientas con el enunciado, responde con un número desde el 1 y hasta el 5, 5 significa que te sientes muy identificado y 1 que no te sientes nada identificado.</source>
            <comment>Text</comment>
            <translation type="obsolete">A continuación mencionaré 10 enunciados, dependiendo de que tan identificado te sientas con el enunciado, responde con un número desde el 1 y hasta el 5, 5 significa que te sientes muy identificado y 1 que no te sientes nada identificado.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>A continuación mencionaré 10 enunciados relacionados con tus gustos en películas. Dependiendo de qué tan identificado te sientas con cada enunciado, responde con un número del 1 al 5. El número 5 significa que te sientes muy identificado, y el número 1 significa que no te sientes nada identificado. Esto me ayudará a conocer mejor tus preferencias y recomendarte los géneros de películas que más te pueden gustar. ¡Empecemos!.</source>
            <comment>Text</comment>
            <translation type="unfinished">A continuación mencionaré 10 enunciados relacionados con tus gustos en películas. Dependiendo de qué tan identificado te sientas con cada enunciado, responde con un número del 1 al 5. El número 5 significa que te sientes muy identificado, y el número 1 significa que no te sientes nada identificado. Esto me ayudará a conocer mejor tus preferencias y recomendarte los géneros de películas que más te pueden gustar. ¡Empecemos!.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1</name>
        <message>
            <source>Disfruto resolver problemas matemáticos y analizar información numérica</source>
            <comment>Text</comment>
            <translation type="obsolete">Disfruto resolver problemas matemáticos y analizar información numérica</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1 (1)</name>
        <message>
            <source>Primer enunciado</source>
            <comment>Text</comment>
            <translation type="obsolete">Primer enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1 (10)</name>
        <message>
            <source>Sexto enunciado</source>
            <comment>Text</comment>
            <translation type="obsolete">Sexto enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1 (2)</name>
        <message>
            <source>Segundo enunciado</source>
            <comment>Text</comment>
            <translation type="obsolete">Segundo enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1 (3)</name>
        <message>
            <source>Septimo enunciado</source>
            <comment>Text</comment>
            <translation type="obsolete">Septimo enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1 (4)</name>
        <message>
            <source>Tercer enunciado</source>
            <comment>Text</comment>
            <translation type="obsolete">Tercer enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1 (5)</name>
        <message>
            <source>Octavo enunciado</source>
            <comment>Text</comment>
            <translation type="obsolete">Octavo enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1 (6)</name>
        <message>
            <source>Cuarto enunciado</source>
            <comment>Text</comment>
            <translation type="obsolete">Cuarto enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1 (7)</name>
        <message>
            <source>Noveno enunciado</source>
            <comment>Text</comment>
            <translation type="obsolete">Noveno enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1 (8)</name>
        <message>
            <source>Quinto enunciado</source>
            <comment>Text</comment>
            <translation type="obsolete">Quinto enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1 (9)</name>
        <message>
            <source>Décimo enunciado</source>
            <comment>Text</comment>
            <translation type="obsolete">Décimo enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1/Pregunta 1</name>
        <message>
            <source>Disfruto resolver problemas matemáticos y analizar información numérica</source>
            <comment>Text</comment>
            <translation type="obsolete">Disfruto resolver problemas matemáticos y analizar información numérica</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Me encantan las escenas de acción rápida y emocionantes.</source>
            <comment>Text</comment>
            <translation type="unfinished">Me encantan las escenas de acción rápida y emocionantes.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 1/Pregunta 1 (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Primer enunciado</source>
            <comment>Text</comment>
            <translation type="unfinished">Primer enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 10</name>
        <message>
            <source>Me interesa la optimización de procesos y la mejora de la eficiencia en las empresas.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me interesa la optimización de procesos y la mejora de la eficiencia en las empresas.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 10/Pregunta 1 (9)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Décimo enunciado</source>
            <comment>Text</comment>
            <translation type="unfinished">Décimo enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 10/Pregunta 10</name>
        <message>
            <source>Me interesa la optimización de procesos y la mejora de la eficiencia en las empresas.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me interesa la optimización de procesos y la mejora de la eficiencia en las empresas.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Disfruto de las películas románticas con finales felices.</source>
            <comment>Text</comment>
            <translation type="unfinished">Disfruto de las películas románticas con finales felices.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 2</name>
        <message>
            <source>Me gusta trabajar en proyectos de equipo y colaborar con otros para alcanzar objetivos comunes.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me gusta trabajar en proyectos de equipo y colaborar con otros para alcanzar objetivos comunes.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 2/Pregunta 1 (2)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Segundo enunciado</source>
            <comment>Text</comment>
            <translation type="unfinished">Segundo enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 2/Pregunta 2</name>
        <message>
            <source>Me gusta trabajar en proyectos de equipo y colaborar con otros para alcanzar objetivos comunes.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me gusta trabajar en proyectos de equipo y colaborar con otros para alcanzar objetivos comunes.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Disfruto de las películas con mucho humor y situaciones cómicas.</source>
            <comment>Text</comment>
            <translation type="unfinished">Disfruto de las películas con mucho humor y situaciones cómicas.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 3</name>
        <message>
            <source>Siento curiosidad por cómo funcionan los computadores y disfruto aprender sobre nuevas tecnologías.</source>
            <comment>Text</comment>
            <translation type="obsolete">Siento curiosidad por cómo funcionan los computadores y disfruto aprender sobre nuevas tecnologías.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 3/Pregunta 1 (4)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Tercer enunciado</source>
            <comment>Text</comment>
            <translation type="unfinished">Tercer enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 3/Pregunta 3</name>
        <message>
            <source>Siento curiosidad por cómo funcionan los computadores y disfruto aprender sobre nuevas tecnologías.</source>
            <comment>Text</comment>
            <translation type="obsolete">Siento curiosidad por cómo funcionan los computadores y disfruto aprender sobre nuevas tecnologías.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Prefiero las películas que tocan temas serios y exploran emociones profundas.</source>
            <comment>Text</comment>
            <translation type="unfinished">Prefiero las películas que tocan temas serios y exploran emociones profundas.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 4</name>
        <message>
            <source>Me atrae la idea de diseñar y construir estructuras físicas como puentes, edificios o carreteras.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me atrae la idea de diseñar y construir estructuras físicas como puentes, edificios o carreteras.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 4/Pregunta 1 (6)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Cuarto enunciado</source>
            <comment>Text</comment>
            <translation type="unfinished">Cuarto enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 4/Pregunta 4</name>
        <message>
            <source>Me atrae la idea de diseñar y construir estructuras físicas como puentes, edificios o carreteras.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me atrae la idea de diseñar y construir estructuras físicas como puentes, edificios o carreteras.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Me fascinan las películas de ciencia ficción con mundos futuristas o tecnología avanzada.</source>
            <comment>Text</comment>
            <translation type="unfinished">Me fascinan las películas de ciencia ficción con mundos futuristas o tecnología avanzada.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 5</name>
        <message>
            <source>Me interesa la administración y el funcionamiento de empresas u organizaciones.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me interesa la administración y el funcionamiento de empresas u organizaciones.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 5/Pregunta 1 (8)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Quinto enunciado</source>
            <comment>Text</comment>
            <translation type="unfinished">Quinto enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 5/Pregunta 5</name>
        <message>
            <source>Me interesa la administración y el funcionamiento de empresas u organizaciones.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me interesa la administración y el funcionamiento de empresas u organizaciones.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Disfruto de las historias románticas y relaciones entre personajes con un toque emocional.</source>
            <comment>Text</comment>
            <translation type="unfinished">Disfruto de las historias románticas y relaciones entre personajes con un toque emocional.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 6</name>
        <message>
            <source>Me gusta investigar y descubrir soluciones innovadoras para problemas complejos.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me gusta investigar y descubrir soluciones innovadoras para problemas complejos.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 6/Pregunta 1 (10)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Sexto enunciado</source>
            <comment>Text</comment>
            <translation type="unfinished">Sexto enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 6/Pregunta 6</name>
        <message>
            <source>Me gusta investigar y descubrir soluciones innovadoras para problemas complejos.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me gusta investigar y descubrir soluciones innovadoras para problemas complejos.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Me atraen las películas de aventuras donde los personajes superan grandes desafíos.</source>
            <comment>Text</comment>
            <translation type="unfinished">Me atraen las películas de aventuras donde los personajes superan grandes desafíos.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 7</name>
        <message>
            <source>Me atrae el estudio de los impactos ambientales y la búsqueda de soluciones sostenibles.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me atrae el estudio de los impactos ambientales y la búsqueda de soluciones sostenibles.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 7/Pregunta 1 (3)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Septimo enunciado</source>
            <comment>Text</comment>
            <translation type="unfinished">Septimo enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 7/Pregunta 7</name>
        <message>
            <source>Me atrae el estudio de los impactos ambientales y la búsqueda de soluciones sostenibles.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me atrae el estudio de los impactos ambientales y la búsqueda de soluciones sostenibles.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Me gustan las comedias ligeras que me hacen reír y olvidar los problemas.</source>
            <comment>Text</comment>
            <translation type="unfinished">Me gustan las comedias ligeras que me hacen reír y olvidar los problemas.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 8</name>
        <message>
            <source>Me siento cómodo trabajando con tecnología y disfruto programar o desarrollar software.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me siento cómodo trabajando con tecnología y disfruto programar o desarrollar software.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 8/Pregunta 1 (5)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Octavo enunciado</source>
            <comment>Text</comment>
            <translation type="unfinished">Octavo enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 8/Pregunta 8</name>
        <message>
            <source>Me siento cómodo trabajando con tecnología y disfruto programar o desarrollar software.</source>
            <comment>Text</comment>
            <translation type="obsolete">Me siento cómodo trabajando con tecnología y disfruto programar o desarrollar software.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Valoro las películas que retratan la realidad y los conflictos humanos.</source>
            <comment>Text</comment>
            <translation type="unfinished">Valoro las películas que retratan la realidad y los conflictos humanos.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 9</name>
        <message>
            <source>Disfruto realizar experimentos y trabajar en el campo de la biología o la medicina.</source>
            <comment>Text</comment>
            <translation type="obsolete">Disfruto realizar experimentos y trabajar en el campo de la biología o la medicina.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 9/Pregunta 1 (7)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Noveno enunciado</source>
            <comment>Text</comment>
            <translation type="unfinished">Noveno enunciado</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pregunta 9/Pregunta 9</name>
        <message>
            <source>Disfruto realizar experimentos y trabajar en el campo de la biología o la medicina.</source>
            <comment>Text</comment>
            <translation type="obsolete">Disfruto realizar experimentos y trabajar en el campo de la biología o la medicina.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Me gustan las películas que exploran mundos con robots o criaturas fantásticas.</source>
            <comment>Text</comment>
            <translation type="unfinished">Me gustan las películas que exploran mundos con robots o criaturas fantásticas.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello</translation>
        </message>
    </context>
</TS>
